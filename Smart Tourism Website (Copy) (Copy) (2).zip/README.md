
  # Smart Tourism Website (Copy) (Copy)

  This is a code bundle for Smart Tourism Website (Copy) (Copy). The original project is available at https://www.figma.com/design/lEakgMz7ztKDHTRAJZK1xQ/Smart-Tourism-Website--Copy---Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  