"""SOCIAL & TRAVEL BUDDY ROUTES"""
from flask import Blueprint
bp = Blueprint('social', __name__)
