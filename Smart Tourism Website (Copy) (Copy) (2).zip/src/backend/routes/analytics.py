"""ANALYTICS & REPORTING ROUTES"""
from flask import Blueprint
bp = Blueprint('analytics', __name__)
