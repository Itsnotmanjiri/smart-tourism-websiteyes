"""ITINERARY ROUTES"""
from flask import Blueprint
bp = Blueprint('itineraries', __name__)
