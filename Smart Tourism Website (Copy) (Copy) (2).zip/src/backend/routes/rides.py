"""CARPOOL & RIDE SHARING ROUTES"""
from flask import Blueprint
bp = Blueprint('rides', __name__)
