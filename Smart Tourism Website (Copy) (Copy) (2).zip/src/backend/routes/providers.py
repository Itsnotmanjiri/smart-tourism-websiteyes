"""PROVIDER DASHBOARD ROUTES"""
from flask import Blueprint
bp = Blueprint('providers', __name__)
