"""SOS EMERGENCY SYSTEM ROUTES"""
from flask import Blueprint
bp = Blueprint('emergency', __name__)
