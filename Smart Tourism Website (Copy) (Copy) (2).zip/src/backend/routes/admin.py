"""ADMIN DASHBOARD ROUTES"""
from flask import Blueprint
bp = Blueprint('admin', __name__)
