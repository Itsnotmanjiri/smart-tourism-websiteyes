"""BOOKING ROUTES"""
from flask import Blueprint
bp = Blueprint('bookings', __name__)
