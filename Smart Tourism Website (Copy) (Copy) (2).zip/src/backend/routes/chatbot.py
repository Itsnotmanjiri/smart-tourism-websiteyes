"""AI CHATBOT ROUTES"""
from flask import Blueprint
bp = Blueprint('chatbot', __name__)
